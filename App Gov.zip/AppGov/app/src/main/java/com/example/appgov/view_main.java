package com.example.appgov;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class view_main extends AppCompatActivity {

    private Spinner spinnerRequest;
    private EditText etMonths, etS1, etS2, etS3;
    private Button btnCalculate;
    private TextView tvResult;

    // Valores oficiais - fixos.
    private static final double LIMITE1 = 2041.39;
    private static final double LIMITE2 = 3402.65;
    private static final double FIXO_FAIXA2 = 1633.10;
    private static final double TETO = 2313.74;
    private static final double SALARIO_MINIMO = 1412.00;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_view_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        spinnerRequest = findViewById(R.id.spinnerRequest);
        etMonths = findViewById(R.id.etMonths);
        etS1 = findViewById(R.id.etS1);
        etS2 = findViewById(R.id.etS2);
        etS3 = findViewById(R.id.etS3);
        btnCalculate = findViewById(R.id.btnCalculate);
        tvResult = findViewById(R.id.tvResult);


        String[] items = {"1ª solicitação", "2ª solicitação", "3ª ou mais"};
        spinnerRequest.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items));

        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcular();
            }
        });
    }

    private void calcular() {
        String monthsStr = etMonths.getText().toString().trim();
        int months = 0;
        try {
            months = monthsStr.isEmpty() ? 0 : Integer.parseInt(monthsStr);
        } catch (NumberFormatException e) {
            tvResult.setText("Meses inválidos");
            return;
        }

        ArrayList<Double> salarios = new ArrayList<>();
        parseAdd(etS1.getText().toString(), salarios);
        parseAdd(etS2.getText().toString(), salarios);
        parseAdd(etS3.getText().toString(), salarios);

        if (salarios.size() == 0) {
            tvResult.setText("Informe pelo menos 1 salário para cálculo.");
            return;
        }

        double media = 0.0;
        for (Double s : salarios) media += s;
        media = media / salarios.size();

        double parcela = calculaParcela(media);
        parcela = Math.max(parcela, SALARIO_MINIMO);

        int requestType = spinnerRequest.getSelectedItemPosition(); // 0,1,2
        int parcelas = calculaQuantidadeParcelas(requestType, months);

        NumberFormat nf = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
        StringBuilder sb = new StringBuilder();
        sb.append("Média salarial: ").append(nf.format(media)).append("\n");
        sb.append("Valor da parcela: ").append(nf.format(round2(parcela))).append("\n");

        if (parcelas == 0) {
            sb.append("Com base nos meses informados e no tipo de solicitação, o trabalhador NÃO tem direito às parcelas (não preenche os requisitos).");
        } else {
            sb.append("Quantidade de parcelas: ").append(parcelas).append("\n");
            sb.append("Total aproximado: ").append(nf.format(round2(parcela * parcelas)));
        }

        tvResult.setText(sb.toString());
    }

    private void parseAdd(String s, ArrayList<Double> list) {
        if (s == null) return;
        s = s.trim();
        if (s.isEmpty()) return;
        try {
            double v = Double.parseDouble(s.replace(",", "."));
            if (v > 0) list.add(v);
        } catch (NumberFormatException ignored) {}
    }

    private double calculaParcela(double media) {
        if (media <= LIMITE1) {
            return media * 0.8;
        } else if (media <= LIMITE2) {
            return FIXO_FAIXA2 + 0.5 * (media - LIMITE1);
        } else {
            return TETO;
        }
    }

    private int calculaQuantidadeParcelas(int requestType, int months) {
        if (requestType == 0) {
            if (months >= 12 && months <= 23) return 4;
            if (months >= 24) return 5;
            return 0;
        } else if (requestType == 1) {
            if (months >= 9 && months <= 11) return 3;
            if (months >= 12 && months <= 23) return 4;
            if (months >= 24) return 5;
            return 0;
        } else {
            if (months >= 6 && months <= 11) return 3;
            if (months >= 12 && months <= 23) return 4;
            if (months >= 24) return 5;
            return 0;
        }
    }
    private double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }
}