package com.example.busapp;

import static android.widget.Toast.LENGTH_SHORT;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

    public class Assentos extends AppCompatActivity {
        private List<ImageView> assentosSelecionados = new ArrayList<>();
        private double precoDaViagem = 0.0; // Inicia com 0 como padrão de segurança
        private TextView tvValorTotal;
        private Button btn_confirmar_reserva;
        private ImageView assento1a, assento1c, assento1d, assento_2a, assento_2b, assento_2d;
        private ImageView assento_3a, assento_3b, assento_3c, assento_3d;
        private ImageView assento_4a, assento_4b, assento_4c, assento_4d;
        private ImageView assento_5a, assento_5b, assento_5c, assento_5d;
        private ImageView assento_6a, assento_6b, assento_6c, assento_6d;

        private String horarioPartida;
        private String horarioChegada;
        private String origem;
        private String destino;
        private  String dataViagem;
        private double precoBase;
        private  double precoTotal;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_assentos);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Intent intent = getIntent();
        origem = intent.getStringExtra("ORIGEM");
        destino = intent.getStringExtra("DESTINO");
        horarioPartida = intent.getStringExtra("HORARIO_PARTIDA");
        horarioChegada = intent.getStringExtra("HORARIO_CHEGADA");
        precoBase = intent.getDoubleExtra("PRECO_BASE", 0.0); // Preço por assento
        dataViagem = intent.getStringExtra("DATA_VIAGEM");

        tvValorTotal = findViewById(R.id.tv_valor_total);
        btn_confirmar_reserva = findViewById(R.id.btn_confirmar_reserva);

        assento1a = findViewById(R.id.assento_1a);
        assento1c = findViewById(R.id.assento_1c);
        assento1d = findViewById(R.id.assento_1d);

        assento_2a = findViewById(R.id.assento_2a);
        assento_2b = findViewById(R.id.assento_2b);
        assento_2d = findViewById(R.id.assento_2d);

        assento_3a = findViewById(R.id.assento_3a);
        assento_3b = findViewById(R.id.assento_3b);
        assento_3c = findViewById(R.id.assento_3c);
        assento_3d = findViewById(R.id.assento_3d);

        assento_4a = findViewById(R.id.assento_4a);
        assento_4b = findViewById(R.id.assento_4b);
        assento_4c = findViewById(R.id.assento_4c);
        assento_4d = findViewById(R.id.assento_4d);

        assento_5a = findViewById(R.id.assento_5a);
        assento_5b = findViewById(R.id.assento_5b);
        assento_5c = findViewById(R.id.assento_5c);
        assento_5d = findViewById(R.id.assento_5d);

        assento_6a = findViewById(R.id.assento_6a);
        assento_6b = findViewById(R.id.assento_6b);
        assento_6c = findViewById(R.id.assento_6c);
        assento_6d = findViewById(R.id.assento_6d);


        assento1a.setOnClickListener(this::onAssentoClicked);
        assento1c.setOnClickListener(this::onAssentoClicked);
        assento1d.setOnClickListener(this::onAssentoClicked);

        assento_2a.setOnClickListener(this::onAssentoClicked);
        assento_2b.setOnClickListener(this::onAssentoClicked);
        assento_2d.setOnClickListener(this::onAssentoClicked);

        assento_3a.setOnClickListener(this::onAssentoClicked);
        assento_3b.setOnClickListener(this::onAssentoClicked);
        assento_3c.setOnClickListener(this::onAssentoClicked);
        assento_3d.setOnClickListener(this::onAssentoClicked);

        assento_4a.setOnClickListener(this::onAssentoClicked);
        assento_4b.setOnClickListener(this::onAssentoClicked);
        assento_4c.setOnClickListener(this::onAssentoClicked);
        assento_4d.setOnClickListener(this::onAssentoClicked);

        assento_5a.setOnClickListener(this::onAssentoClicked);
        assento_5b.setOnClickListener(this::onAssentoClicked);
        assento_5c.setOnClickListener(this::onAssentoClicked);
        assento_5d.setOnClickListener(this::onAssentoClicked);

        assento_6a.setOnClickListener(this::onAssentoClicked);
        assento_6b.setOnClickListener(this::onAssentoClicked);
        assento_6c.setOnClickListener(this::onAssentoClicked);
        assento_6d.setOnClickListener(this::onAssentoClicked);

        btn_confirmar_reserva.setOnClickListener(v -> {

            if (assentosSelecionados.isEmpty()) {
                Toast.makeText(this, "Selecione pelo menos um assento.", LENGTH_SHORT).show();
                return;
            }

            ArrayList<String> nomesDosAssentos = new ArrayList<>();
            for (ImageView assentoView : assentosSelecionados) {
                String nomeDoAssento = getResources().getResourceEntryName(assentoView.getId());
                nomesDosAssentos.add(nomeDoAssento);
            }


            Intent proximaTelaIntent = new Intent(Assentos.this, CadastroUsuario.class);

            // --- Informações da primeira tela (Horários) ---
            proximaTelaIntent.putExtra("ORIGEM", origem);
            proximaTelaIntent.putExtra("DESTINO", destino);
            proximaTelaIntent.putExtra("HORARIO_PARTIDA", horarioPartida); // <-- FALTAVA ESTE
            proximaTelaIntent.putExtra("HORARIO_CHEGADA", horarioChegada); // <-- E ESTE
            proximaTelaIntent.putExtra("DATA_VIAGEM", dataViagem);
            proximaTelaIntent.putExtra("PRECO_BASE", precoBase);

            // --- Informações novas desta tela (Assentos) ---
            proximaTelaIntent.putStringArrayListExtra("ASSENTOS_ESCOLHIDOS", nomesDosAssentos);
            proximaTelaIntent.putExtra("PRECO_TOTAL", precoTotal = assentosSelecionados.size() * precoBase);

            startActivity(proximaTelaIntent);

            atualizarTotal();

        });

    }



    private void onAssentoClicked(View view) {
        ImageView assentoClicado = (ImageView) view;

        boolean isSelected = assentoClicado.getTag() != null && (boolean) assentoClicado.getTag();

        if (isSelected) {
            // Se já estava selecionado, volta ao estado disponível
            assentoClicado.setBackgroundResource(R.drawable.seat_available);
            assentoClicado.setTag(false);
            assentosSelecionados.remove(assentoClicado);
        } else {
            // Se estava disponível, muda para o estado selecionado
            assentoClicado.setBackgroundResource(R.drawable.seat_selected);
            assentoClicado.setTag(true);
            assentosSelecionados.add(assentoClicado);
        }

        atualizarTotal();
    }

    private void atualizarTotal() {
        double total = assentosSelecionados.size() * precoBase;
        tvValorTotal.setText(String.format(Locale.getDefault(), "Valor Total: R$ %.2f", total));
    }
}