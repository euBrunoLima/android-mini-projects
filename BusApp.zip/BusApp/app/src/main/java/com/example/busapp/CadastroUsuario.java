package com.example.busapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.Locale;

public class CadastroUsuario extends AppCompatActivity {

    private static final String TAG = "FinalizarReserva";

    // --- Componentes da Tela (do seu XML) ---
    private TextInputEditText editTextNome;
    private TextInputEditText editTextDataNascimento;
    private TextInputEditText editTextCpf;
    private Button btnFinalizarReserva;

    // --- Dados recebidos da Intent ---
    private String origem, destino, dataViagem, horarioChegada,horarioPartida ;
    private ArrayList<String> assentosEscolhidos;
    private double precoBase, precoTotal;

    private Viagem viagemFinal;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cadastro_usuario);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // 1. Recebe os dados das telas anteriores
        receberDadosDaIntent();

        // 2. Vincula os componentes do seu XML
        editTextNome = findViewById(R.id.editTextNome);
        editTextDataNascimento = findViewById(R.id.editTextDataNascimento);
        editTextCpf = findViewById(R.id.editTextCpf);
        btnFinalizarReserva = findViewById(R.id.btnFinalizarReserva);


        btnFinalizarReserva.setOnClickListener(view -> {

            String nome = editTextNome.getText().toString().trim();
            String dataNasc = editTextDataNascimento.getText().toString().trim();
            String cpf = editTextCpf.getText().toString().trim();


            if (nome.isEmpty() || dataNasc.isEmpty() || cpf.isEmpty()) {
                Toast.makeText(this, "Por favor, preencha todos os dados do passageiro.", Toast.LENGTH_SHORT).show();
                return;
            }

            viagemFinal = new Viagem(
                    origem,
                    destino,
                    dataViagem,
                    assentosEscolhidos,
                    precoBase,
                    precoTotal,
                    nome,
                    cpf,
                    dataNasc
            );

            Toast.makeText(this, "Reserva finalizada para " + nome, Toast.LENGTH_LONG).show();
            Log.d(TAG, "Objeto Viagem FINAL gerado com sucesso!");
            Log.d(TAG, "Detalhes: " + viagemFinal.toString());



            Log.d(TAG, "===== Objeto Viagem SENDO ENVIADO =====");
            Log.d(TAG, "Passageiro: " + viagemFinal.getNomePassageiro());
            Log.d(TAG, "CPF: " + viagemFinal.getCpfPassageiro());
            Log.d(TAG, "DataNasc" + viagemFinal.getDataNascimentoPassageiro());
            Log.d(TAG, "Origem: " + viagemFinal.getOrigem());
            Log.d(TAG, "Destino: " + viagemFinal.getDestino());
            Log.d(TAG, "Data da Viagem: " + viagemFinal.getDataViagem());
            Log.d(TAG, "Preço Final: " + viagemFinal.getPrecoFinal());
            Log.d(TAG, "Assentos: " + viagemFinal.getAssentosEscolhidos().toString());
            Log.d(TAG, "=======================================");

            Intent intent = new Intent(this, Pagamento.class);
            intent.putExtra("VIAGEM_OBJ",viagemFinal);
            startActivity(intent);

        });

    }

    private void receberDadosDaIntent() {
        Intent intent = getIntent();
        origem = intent.getStringExtra("ORIGEM");
        destino = intent.getStringExtra("DESTINO");
        dataViagem = intent.getStringExtra("DATA_VIAGEM");
        assentosEscolhidos = intent.getStringArrayListExtra("ASSENTOS_ESCOLHIDOS");
        precoBase = intent.getDoubleExtra("PRECO_BASE", 0.0);
        precoTotal = intent.getDoubleExtra("PRECO_TOTAL", 0.0);
    }

}

