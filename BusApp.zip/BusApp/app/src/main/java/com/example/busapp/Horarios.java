package com.example.busapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Horarios extends AppCompatActivity {

    public static final String CHAVE_ORIGEM = "CHAVE_ORIGEM";
    public static final String CHAVE_DESTINO = "CHAVE_DESTINO";

    private TextView tv_origem_card1, tv_destino_card1, tv_origem_card2, tv_destino_card2, tv_origem_card3, tv_destino_card3;
    private LinearLayout card1, card2, card3;
    private Button btn_confirmar;

    private String horarioPartidaSelecionado = null;
    private String horarioChegadaSelecionado;
    private String origemSelecionada;
    private String destinoSelecionado;
    private String dataViagem;
    private double precoBaseSelecionado;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_horarios);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        tv_origem_card1 = findViewById(R.id.tv_origem_card1);
        tv_destino_card1 = findViewById(R.id.tv_destino_card1);

        tv_origem_card2 = findViewById(R.id.tv_origem_card2);
        tv_destino_card2 = findViewById(R.id.tv_destino_card2);

        tv_origem_card3 = findViewById(R.id.tv_origem_card3);
        tv_destino_card3 = findViewById(R.id.tv_destino_card3);

        card1 = findViewById(R.id.card_1);
        card2 = findViewById(R.id.card_2);
        card3 = findViewById(R.id.card_3);
        btn_confirmar = findViewById(R.id.btn_confirmar);

        resgatarDestinoOrigem();


        card1.setOnClickListener(v -> {
            horarioPartidaSelecionado = "17:00";
            horarioChegadaSelecionado = "23:00";
            origemSelecionada = tv_origem_card1.getText().toString();
            destinoSelecionado = tv_destino_card1.getText().toString();
            precoBaseSelecionado = 6.15;
            selecionarCard(card1);
            Toast.makeText(this, "Horário das 17:00 selecionado", Toast.LENGTH_SHORT).show();
        });

        card2.setOnClickListener(v -> {
            horarioPartidaSelecionado = "17:30";
            horarioChegadaSelecionado = "23:30";
            origemSelecionada = tv_origem_card2.getText().toString();
            destinoSelecionado = tv_destino_card2.getText().toString();
            precoBaseSelecionado = 150.80;
            selecionarCard(card2);
            Toast.makeText(this, "Horário das 17:30 selecionado", Toast.LENGTH_SHORT).show();
        });

        card3.setOnClickListener(v -> {
            horarioPartidaSelecionado = "18:00";
            horarioChegadaSelecionado = "24:00";
            origemSelecionada = tv_origem_card3.getText().toString();
            destinoSelecionado = tv_destino_card3.getText().toString();
            precoBaseSelecionado = 45.90;
            selecionarCard(card3);
            Toast.makeText(this, "Horário das 18:00 selecionado", Toast.LENGTH_SHORT).show();
        });

        btn_confirmar.setOnClickListener(v -> {
            if (horarioPartidaSelecionado == null) {
                Toast.makeText(this, "Por favor, selecione um horário.", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(this, Assentos.class);
                intent.putExtra("HORARIO_PARTIDA", horarioPartidaSelecionado);
                intent.putExtra("HORARIO_CHEGADA", horarioChegadaSelecionado);
                intent.putExtra("ORIGEM", origemSelecionada);
                intent.putExtra("DESTINO", destinoSelecionado);
                intent.putExtra("PRECO_BASE", precoBaseSelecionado);
                intent.putExtra("DATA_VIAGEM", dataViagem);
                startActivity(intent);
            }
        });

    }

    private void resgatarDestinoOrigem(){
        Intent intent = getIntent();

        String origem = intent.getStringExtra("CHAVE_ORIGEM");
        String destino = intent.getStringExtra("CHAVE_DESTINO");
        dataViagem = intent.getStringExtra("DATA_VIAGEM");

        if (origem != null && destino != null) {
            tv_origem_card1.setText(origem);
            tv_destino_card1.setText(destino);

            tv_origem_card2.setText(origem);
            tv_destino_card2.setText(destino);

            tv_origem_card3.setText(origem);
            tv_destino_card3.setText(destino);
        }
    }

    private void selecionarCard(LinearLayout cardSelecionado) {
        card1.setBackgroundResource(R.drawable.card_background);
        card2.setBackgroundResource(R.drawable.card_background);
        card3.setBackgroundResource(R.drawable.card_background);

        // Destaca apenas o card que foi clicado
        cardSelecionado.setBackgroundResource(R.drawable.card_background_selected);
    }
}