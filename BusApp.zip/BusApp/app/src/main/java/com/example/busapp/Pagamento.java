
package com.example.busapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Pagamento extends AppCompatActivity {


    private Button btn_pix, btn_cartao, btn_boleto;
    private Viagem viagemRecebida;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pagamento);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });



        btn_pix = findViewById(R.id.btn_pix);
        btn_cartao = findViewById(R.id.btn_cartao);
        btn_boleto = findViewById(R.id.btn_boleto);

        viagemRecebida = getIntent().getParcelableExtra("VIAGEM_OBJ");


        if (viagemRecebida == null) {
            Toast.makeText(this, "Erro: dados da viagem não encontrados.", Toast.LENGTH_LONG).show();
            finish(); // Fecha a tela se não houver dados
            return;
        }

        btn_pix.setOnClickListener(v -> iniciarTelaFinal("pix"));
        btn_cartao.setOnClickListener(v -> iniciarTelaFinal("cartao"));
        btn_boleto.setOnClickListener(v -> iniciarTelaFinal("boleto"));

    }


    private void iniciarTelaFinal(String metodoPagamento) {
        Intent intent = new Intent(this, ViewFinal.class);
        intent.putExtra("VIAGEM_OBJ", viagemRecebida); // Usa o objeto guardado
        intent.putExtra("METODO_PAGAMENTO", metodoPagamento);
        startActivity(intent);
    }
}