package com.example.busapp;

public class User {
    public static String usuario;
    public static String senha; // para facilitar, pode deixar visível

    public User(String usuario, String senha) {
        this.usuario = "admin";
        this.senha = "admin" ;
    }

    public boolean verificarLogin(String usuarioDigitado, String senhaDigitada) {
        return usuario.equals(usuarioDigitado) && senha.equals(senhaDigitada);
    }


}
