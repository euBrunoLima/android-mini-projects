package com.example.busapp;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.util.List;

public class Viagem implements Parcelable {
    // Dados do Trajeto
    private String origem;
    private String destino;
    private String dataViagem;

    // Dados da Reserva
    private List<String> assentosEscolhidos;
    private double precoPassagem;
    private double precoFinal;

    // Dados do Passageiro (integrados na mesma classe)
    private String nomePassageiro;
    private String cpfPassageiro;
    private String dataNascimentoPassageiro; // Usando String para simplicidade

    // Construtor com todos os camposx
    public Viagem(String origem, String destino, String dataViagem,
                  List<String> assentosEscolhidos,double precoPassagem, double precoFinal,
                  String nomePassageiro, String cpfPassageiro, String dataNascimentoPassageiro) {

        this.origem = origem;
        this.destino = destino;
        this.dataViagem = dataViagem;
        this.assentosEscolhidos = assentosEscolhidos;
        this.precoPassagem = precoPassagem;
        this.precoFinal = precoFinal;
        this.nomePassageiro = nomePassageiro;
        this.cpfPassageiro = cpfPassageiro;
        this.dataNascimentoPassageiro = dataNascimentoPassageiro;
    }

    // --- Getters e Setters ---

    protected Viagem(Parcel in) {
        origem = in.readString();
        destino = in.readString();
        dataViagem = in.readString();
        assentosEscolhidos = in.createStringArrayList();
        precoFinal = in.readDouble();
        precoPassagem = in.readDouble();
        nomePassageiro = in.readString();
        cpfPassageiro = in.readString();
        dataNascimentoPassageiro = in.readString();
    }

    public static final Creator<Viagem> CREATOR = new Creator<Viagem>() {
        @Override
        public Viagem createFromParcel(Parcel in) {
            return new Viagem(in);
        }

        @Override
        public Viagem[] newArray(int size) {
            return new Viagem[size];
        }
    };

    public String getOrigem() {
        return origem;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public String getDataViagem() {
        return dataViagem;
    }

    public void setDataViagem(String dataViagem) {
        this.dataViagem = dataViagem;
    }

    public List<String> getAssentosEscolhidos() {
        return assentosEscolhidos;
    }

    public void setAssentosEscolhidos(List<String> assentosEscolhidos) {
        this.assentosEscolhidos = assentosEscolhidos;
    }

    public double getPrecoFinal() {
        return precoFinal;
    }
    public double getPrecoPassagem(){
        return  precoPassagem;
    }
    public void setPrecoFinal(double precoFinal) {
        this.precoFinal = precoFinal;
    }

    public String getNomePassageiro() {
        return nomePassageiro;
    }

    public void setNomePassageiro(String nomePassageiro) {
        this.nomePassageiro = nomePassageiro;
    }

    public String getCpfPassageiro() {
        return cpfPassageiro;
    }

    public void setCpfPassageiro(String cpfPassageiro) {
        this.cpfPassageiro = cpfPassageiro;
    }

    public String getDataNascimentoPassageiro() {
        return dataNascimentoPassageiro;
    }

    public void setDataNascimentoPassageiro(String dataNascimentoPassageiro) {
        this.dataNascimentoPassageiro = dataNascimentoPassageiro;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(origem);
        parcel.writeString(destino);
        parcel.writeString(dataViagem);
        parcel.writeStringList(assentosEscolhidos);
        parcel.writeDouble(precoFinal);
        parcel.writeDouble(precoPassagem);
        parcel.writeString(nomePassageiro);
        parcel.writeString(cpfPassageiro);
        parcel.writeString(dataNascimentoPassageiro);
    }
}