package com.example.busapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Calendar;

public class ViewDestino extends AppCompatActivity {

    private Spinner spinnerOrigem, spinnerDestino;
    private TextView tv_data_viagem;
    private CalendarView calendarView_data_viagem;
    private Button btn_buscar_passagem;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_view_destino);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        spinnerOrigem = findViewById(R.id.spinner_origem);
        spinnerDestino = findViewById(R.id.spinner_destino);
        tv_data_viagem = findViewById(R.id.tv_data_viagem);
        calendarView_data_viagem = findViewById(R.id.calendarView_data_viagem);
        btn_buscar_passagem = findViewById(R.id.btn_buscar_passagem);

        mostrarDataAtual();
        configurarSpinner();

        btn_buscar_passagem.setOnClickListener(view -> {
            String dataViagem = tv_data_viagem.getText().toString();

            String origemSelecionada = spinnerOrigem.getSelectedItem().toString();

            String destinoSelecionado = spinnerDestino.getSelectedItem().toString();

            if (origemSelecionada.equals(destinoSelecionado)) {
                Toast.makeText(this, "A origem e o destino não podem ser iguais!", Toast.LENGTH_LONG).show();
                return;
            }

            Intent intent = new Intent(this, Horarios.class);
            intent.putExtra("CHAVE_ORIGEM", origemSelecionada);
            intent.putExtra("CHAVE_DESTINO", destinoSelecionado);
            intent.putExtra("DATA_VIAGEM",dataViagem);

            startActivity(intent);


        });
        calendarView_data_viagem.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                int mesCorrigido = month + 1;
                String dataSelecionada = String.format("%02d/%02d/%d", dayOfMonth, mesCorrigido, year);
                tv_data_viagem.setText(dataSelecionada);
            }
        });



    }

    private void mostrarDataAtual() {
        Calendar calendario = Calendar.getInstance();
        int dia = calendario.get(Calendar.DAY_OF_MONTH);
        int mes = calendario.get(Calendar.MONTH) + 1; // Mês também é base 0
        int ano = calendario.get(Calendar.YEAR);

        String dataAtual = String.format("%02d/%02d/%d", dia, mes, ano);
        tv_data_viagem.setText(dataAtual);
    }
    private void configurarSpinner(){
        String[] estados = new String[] {
                "Acre", "Alagoas", "Amapá", "Amazonas", "Bahia", "Ceará",
                "Distrito Federal", "Espírito Santo", "Goiás", "Maranhão",
                "Mato Grosso", "Mato Grosso do Sul", "Minas Gerais", "Pará",
                "Paraíba", "Paraná", "Pernambuco", "Piauí", "Rio de Janeiro",
                "Rio Grande do Norte", "Rio Grande do Sul", "Rondônia",
                "Roraima", "Santa Catarina", "São Paulo", "Sergipe", "Tocantins"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, estados);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerOrigem.setAdapter(adapter);
        spinnerDestino.setAdapter(adapter);
    }
}