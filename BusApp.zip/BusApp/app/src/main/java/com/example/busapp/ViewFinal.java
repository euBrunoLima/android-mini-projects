package com.example.busapp;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ViewFinal extends AppCompatActivity {

    private Viagem VIAGEM_OBJ;
    private Button btn_fechar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_view_final);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btn_fechar = findViewById(R.id.btn_fechar);

        btn_fechar.setOnClickListener( v ->{
            finishAffinity();
            System.exit(0);
        });

        VIAGEM_OBJ = getIntent().getParcelableExtra("VIAGEM_OBJ");

        if (VIAGEM_OBJ != null) {
            // --- VINCULA TODOS OS COMPONENTES DO XML ---
            TextView tvNome = findViewById(R.id.tv_final_nome_passageiro);
            TextView tvCpf = findViewById(R.id.tv_final_cpf_passageiro);
            TextView tvDataNascimento = findViewById(R.id.tv_final_data_nascimento); // NOVO
            TextView tvTrajeto = findViewById(R.id.tv_final_trajeto);
            TextView tvDataViagem = findViewById(R.id.tv_final_data_viagem);     // NOVO
            TextView tvAssentos = findViewById(R.id.tv_final_assentos);
            TextView tvPreco = findViewById(R.id.tv_final_preco);


            tvNome.setText("Passageiro: " + VIAGEM_OBJ.getNomePassageiro());
            tvCpf.setText("CPF: " + VIAGEM_OBJ.getCpfPassageiro());
            tvDataNascimento.setText("Data de Nascimento: " + VIAGEM_OBJ.getDataNascimentoPassageiro()); // NOVO
            tvTrajeto.setText("Trajeto: " + VIAGEM_OBJ.getOrigem() + " -> " + VIAGEM_OBJ.getDestino());
            tvDataViagem.setText("Data da Viagem: " + VIAGEM_OBJ.getDataViagem()); // NOVO
            tvAssentos.setText("Assentos: " + VIAGEM_OBJ.getAssentosEscolhidos().toString());

            String precoFormatado = String.format("Valor Total: R$ %.2f", VIAGEM_OBJ.getPrecoFinal());
            tvPreco.setText(precoFormatado);

        } else {
            Log.e(TAG, "ERRO: O objeto 'VIAGEM_OBJ' chegou como nulo!");
            TextView tvNome = findViewById(R.id.tv_final_nome_passageiro);
            tvNome.setText("Erro ao carregar dados da passagem.");
        }
    }
}