package com.example.busapp;

import static android.widget.Toast.LENGTH_SHORT;



import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ViewLogin extends AppCompatActivity {

    private  EditText ed_pass, ed_user;
    private Button btn_login, btn_finalizar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_view_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ed_user = findViewById(R.id.ed_user);
        ed_pass = findViewById(R.id.ed_pass);
        btn_login = findViewById(R.id.btn_login);
        btn_finalizar = findViewById(R.id.btn_finalizar);

        btn_login.setOnClickListener(v ->{
            fazerLogin();
        });
        btn_finalizar.setOnClickListener(v ->{
            finishAffinity();
            System.exit(0);
        });
    }

    private void fazerLogin(){
        try {
            String user = ed_user.getText().toString().trim();
            String pass = ed_pass.getText().toString().trim();

            User user1 = new User(user, pass);

            if(user1.verificarLogin(user,pass)){
                Toast.makeText(this, "Login realizado com sucesso!", LENGTH_SHORT).show();
                Intent intent = new Intent(this, ViewDestino.class);
                startActivity(intent);
            }else{
                Toast.makeText(this, "Usuário ou senha incorreto!", LENGTH_SHORT).show();
            }

        }catch (Error error){
            Toast.makeText(this, "Erro interno ao fazer login!", LENGTH_SHORT).show();
        }
    }

}