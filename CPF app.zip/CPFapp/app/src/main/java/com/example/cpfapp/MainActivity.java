package com.example.cpfapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText editCpf;
    private Button buttonVerificar;
    private TextView textRegiaoEmissao, textDigitoControle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editCpf = findViewById(R.id.edit_cpf);
        buttonVerificar = findViewById(R.id.button_verificar_cpf);
        textRegiaoEmissao = findViewById(R.id.text_regiao_emissao);
        textDigitoControle = findViewById(R.id.text_digito_controle);


        buttonVerificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verificarCpf();
            }
        });
    }


    private void verificarCpf() {
        String cpf = editCpf.getText().toString();

        cpf = cpf.replaceAll("[^0-9]", "");

        if (cpf.length() != 11) {
            Toast.makeText(this, "Por favor, digite um CPF válido com 11 dígitos.", Toast.LENGTH_SHORT).show();

            textRegiaoEmissao.setText("Região de Emissão: ");
            textDigitoControle.setText("Dígito de Controle: ");
            return;
        }

        int digitoRegiao = Character.getNumericValue(cpf.charAt(8));

        String digitoControle = cpf.substring(9, 11);

        String regiao = obterRegiaoPorDigito(digitoRegiao);


        textRegiaoEmissao.setText("Região de Emissão: " + regiao);
        textDigitoControle.setText("Dígito de Controle: " + digitoControle);
    }

    private String obterRegiaoPorDigito(int digito) {
        switch (digito) {
            case 0:
                return "Rio Grande do Sul";
            case 1:
                return "Distrito Federal, Goiás, Mato Grosso, Mato Grosso do Sul e Tocantins";
            case 2:
                return "Amazonas, Pará, Roraima, Amapá, Acre e Rondônia";
            case 3:
                return "Ceará, Maranhão e Piauí";
            case 4:
                return "Paraíba, Pernambuco, Alagoas e Rio Grande do Norte";
            case 5:
                return "Bahia e Sergipe";
            case 6:
                return "Minas Gerais";
            case 7:
                return "Rio de Janeiro e Espírito Santo";
            case 8:
                return "São Paulo";
            case 9:
                return "Paraná e Santa Catarina";
            default:
                return "Dígito inválido";
        }
    }
}