package com.example.calculahipotenusa;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText editCateto1, editCateto2;
    private Button buttonCalcular;
    private TextView textResultado;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editCateto1 = findViewById(R.id.edit_cateto1);
        editCateto2 = findViewById(R.id.edit_cateto2);
        buttonCalcular = findViewById(R.id.button_calcular_hipotenusa);
        textResultado = findViewById(R.id.text_resultado_hipotenusa);

        buttonCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularHipotenusa();
            }
        });
    }

    private void calcularHipotenusa() {

        String cateto1String = editCateto1.getText().toString();
        String cateto2String = editCateto2.getText().toString();


        if (cateto1String.isEmpty() || cateto2String.isEmpty()) {
            Toast.makeText(this, "Preencha ambos os catetos", Toast.LENGTH_SHORT).show();
            return;
        }

        try {

            double cateto1 = Double.parseDouble(cateto1String);
            double cateto2 = Double.parseDouble(cateto2String);


            double somaDosQuadrados = (cateto1 * cateto1) + (cateto2 * cateto2);


            double hipotenusa = Math.sqrt(somaDosQuadrados);


            String resultado = String.format("A hipotenusa é: %.2f", hipotenusa);
            textResultado.setText(resultado);

        } catch (NumberFormatException e) {

            Toast.makeText(this, "Por favor, insira números válidos", Toast.LENGTH_SHORT).show();
        }
    }
}