package com.example.contatossqlite;

public class Contato {
    // Atributos [cite: 14-18]
    private int id;
    private String nome;
    private String celular;
    private String email;

    // Construtores [cite: 20]
    public Contato() {
        // Construtor vazio
        this.id = 0;
        this.nome = "";
        this.celular = "";
        this.email = "";
    }

    public Contato(String nome, String celular, String email) {
        this.nome = nome;
        this.celular = celular;
        this.email = email;
    }


    // Métodos gets e sets [cite: 36]
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
