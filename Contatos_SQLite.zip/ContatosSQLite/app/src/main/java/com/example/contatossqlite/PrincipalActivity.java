package com.example.contatossqlite;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PrincipalActivity extends AppCompatActivity {

    private Button btSalvar, btApagar, btConsultar;
    private EditText edNome, edCelular, edEmail;
    private TextView txtId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_principal);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btSalvar = findViewById(R.id.btSalvar);
        btApagar = findViewById(R.id.btExcluir);
        btConsultar = findViewById(R.id.btConsultar);
        edNome = findViewById(R.id.edNome);
        edCelular = findViewById(R.id.edCelular);
        edEmail = findViewById(R.id.edEmail);
        txtId = findViewById(R.id.txtId);

        // Ação do Botão Salvar (Cadastrar)
        btSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Contato c = new Contato();
                c.setNome(edNome.getText().toString());
                c.setCelular(edCelular.getText().toString());
                c.setEmail(edEmail.getText().toString());

                ContatoDAO dao = new ContatoDAO(PrincipalActivity.this);
                dao.salvarContato(c);

                Toast.makeText(PrincipalActivity.this, "Contato gravado com sucesso", Toast.LENGTH_SHORT).show();
                limparCampos();
            }
        });

        // Ação do Botão Apagar (Excluir)
        btApagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ContatoDAO dao = new ContatoDAO(PrincipalActivity.this);
                dao.excluirContato(Integer.parseInt(txtId.getText().toString()));
                Toast.makeText(PrincipalActivity.this, "Contato excluído com sucesso", Toast.LENGTH_SHORT).show();
                limparCampos();
            }
        });

        // Ação do Botão Consultar
        btConsultar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ContatoDAO dao = new ContatoDAO(PrincipalActivity.this);
                Contato c = dao.consultarContatoPorNome(edNome.getText().toString());

                if (c != null) {
                    // Se encontrou, preenche os campos
                    txtId.setText(String.valueOf(c.getId()));
                    edNome.setText(c.getNome());
                    edCelular.setText(c.getCelular());
                    edEmail.setText(c.getEmail());
                } else {
                    // Se não encontrou, avisa o usuário
                    Toast.makeText(PrincipalActivity.this, "Contato não cadastrado", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void limparCampos() {
        txtId.setText("");
        edNome.setText("");
        edCelular.setText("");
        edEmail.setText("");
    }
}
