package com.example.gerasenha;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Map;


public class MainActivity extends AppCompatActivity {

    private TextView textSenhaDisplay;
    private Map<String, Integer> contadores;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textSenhaDisplay = findViewById(R.id.text_senha_display);

        contadores = new HashMap<>();
        contadores.put("Caixa", 0);
        contadores.put("Atendimento", 0);
        contadores.put("AberturaDeConta", 0);
        contadores.put("AtendimentoPreferencial", 0);
        contadores.put("CaixaPreferencial", 0);

        setupButton(R.id.button_caixa, "C");
        setupButton(R.id.button_atendimento, "A");
        setupButton(R.id.button_abertura_conta, "AC");
        setupButton(R.id.button_atendimento_preferencial, "P");
        setupButton(R.id.button_caixa_preferencial, "CP");
    }

    private void setupButton(int buttonId, final String prefixo) {

        Button button = findViewById(buttonId);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gerarSenha(prefixo);
            }
        });
    }

    private void gerarSenha(String prefixo) {
        String nomeServico = getNomeServicoPorPrefixo(prefixo);
        if (nomeServico == null) {
            return;
        }

        int contadorAtual = contadores.get(nomeServico);
        contadorAtual++;
        contadores.put(nomeServico, contadorAtual);

        String senha = String.format("%s%03d", prefixo, contadorAtual);


        textSenhaDisplay.setText(senha);
    }

    private String getNomeServicoPorPrefixo(String prefixo) {
        switch (prefixo) {
            case "C":
                return "Caixa";
            case "A":
                return "Atendimento";
            case "AC":
                return "AberturaDeConta";
            case "P":
                return "AtendimentoPreferencial";
            case "CP":
                return "CaixaPreferencial";
            default:
                return null;
        }
    }
}