package com.example.numerosaleatorios;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private EditText editQuantidade;
    private Button buttonGerar;
    private TextView textResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editQuantidade = findViewById(R.id.edit_quantidade_numeros);
        buttonGerar = findViewById(R.id.button_gerar_numeros);
        textResultado = findViewById(R.id.text_resultado_numeros);

        buttonGerar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               gerarNumerosAleatorios();
            }
        });
    }

    private void gerarNumerosAleatorios() {
        String quantidadeString = editQuantidade.getText().toString();

        if (quantidadeString.isEmpty()) {
            Toast.makeText(this, "Por favor, digite a quantidade de números", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int N = Integer.parseInt(quantidadeString);


            if (N <= 0 || N > 100) {
                Toast.makeText(this, "A quantidade deve ser entre 1 e 100", Toast.LENGTH_LONG).show();
                return;
            }


            Set<Integer> numerosGerados = new HashSet<>();
            Random random = new Random();


            while (numerosGerados.size() < N) {
                int numeroAleatorio = random.nextInt(100); // Gera um número entre 0 e 99
                numerosGerados.add(numeroAleatorio); // Adiciona ao conjunto (se já existir, não faz nada)
            }


            List<Integer> numerosOrdenados = new ArrayList<>(numerosGerados);
            Collections.sort(numerosOrdenados);


            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < numerosOrdenados.size(); i++) {
                sb.append(numerosOrdenados.get(i));
                if (i < numerosOrdenados.size() - 1) {
                    sb.append(", ");
                }
            }

            textResultado.setText(sb.toString());

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Por favor, insira um número válido", Toast.LENGTH_SHORT).show();
        }
    }
}