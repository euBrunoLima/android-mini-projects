package com.example.pesquisa.adm_classes;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.pesquisa.R;
import com.example.pesquisa.classes.Administrador;
import com.example.pesquisa.user_classes.Login;

public class Tela_login_adm extends AppCompatActivity {

    EditText editTextUsuario;
    EditText editTextSenha;
    TextView TV_link_pesquisador;
    Button btn_login;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela_login_adm);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editTextUsuario = findViewById(R.id.editTextUsuario);
        editTextSenha = findViewById(R.id.editTextSenha);
        TV_link_pesquisador = findViewById(R.id.TV_link_adm);
        btn_login = findViewById(R.id.buttonLogin);

        TV_link_pesquisador.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   Intent intent = new Intent(Tela_login_adm.this, Login.class);
                   startActivity(intent);
               }
        });




        btn_login.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                String usuarioDigitado = editTextUsuario.getText().toString();
                String senhaDigitada = editTextSenha.getText().toString();

                Administrador adm = new Administrador();

                 Boolean resultado = adm.verificarLogin(usuarioDigitado, senhaDigitada);

                if(resultado){
                    Intent intent = new Intent(Tela_login_adm.this, Tela_Adm.class);
                    startActivity(intent);
                }else{
                    Toast.makeText(Tela_login_adm.this, "Usuario ou a senha Inválido", Toast.LENGTH_SHORT).show();
                }




            }

        });


    }
}