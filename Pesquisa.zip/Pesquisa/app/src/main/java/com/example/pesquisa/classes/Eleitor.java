package com.example.pesquisa.classes;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class Eleitor {
    private String usuario = "Pesquisador";
    private String senha = "123456";
    private String nome;
    private String celular;
    private String voto;
    private String voto_espontaneo;
    private String problemas;
    private String cidade;
    private String data;
    private String dataHora;


    public Eleitor() {}

    public Eleitor(String nome, String celular, String voto,String voto_espontaneo, String problemas, String cidade) {
        this.nome = nome;
        this.celular = celular;
        this.voto = voto;
        this.voto_espontaneo = voto_espontaneo;
        this.problemas = problemas;
        this.cidade = cidade;

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

        this.data = now.format(dateFormatter);
        this.dataHora = now.format(timeFormatter);
    }


    public Boolean verificarLogin(String usuarioDigitado, String senhaDigitada){
        return usuarioDigitado.equals(getUsuario()) && senhaDigitada.equals(getSenha());
    }

    @Override
    public String toString() {
        return  "\n===== Eleitor =====" +
                "\nNome: " + nome +
                "\nCelular: " + celular +
                "\nVoto: " + voto +
                "\nVoto Espontaneo: " + voto_espontaneo +
                "\nProblemas: " + problemas +
                "\nCidade: " + cidade +
                "\nData: " + data +
                "\nHora: " + dataHora;
    }













    public String getUsuario(){
        return usuario;
    }
    public String getSenha(){
        return senha;
    }

    public String getCelular() {
        return celular;
    }

    public String getCidade() {
        return cidade;
    }

    public String getProblemas() {
        return problemas;
    }

    public String getVoto_espontaneo() {
        return voto_espontaneo;
    }

    public String getVoto() {
        return voto;
    }

    public String getDataHora() {
        return dataHora;
    }

    public String getData() {
        return data;
    }

    public String getNome() {
        return nome;
    }

}
