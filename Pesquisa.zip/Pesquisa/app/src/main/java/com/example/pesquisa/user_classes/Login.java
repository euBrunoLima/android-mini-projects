package com.example.pesquisa.user_classes;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.pesquisa.R;
import com.example.pesquisa.adm_classes.Tela_login_adm;
import com.example.pesquisa.classes.Eleitor;

public class Login extends AppCompatActivity {

    EditText editTextUsuario;
    EditText editTextSenha;
    Button btn_login;
    TextView textViewLinkAdm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editTextUsuario = findViewById(R.id.editTextUsuario);
        editTextSenha = findViewById(R.id.editTextSenha);
        btn_login = findViewById(R.id.btn_login);
        textViewLinkAdm = findViewById(R.id.TV_link_adm);

        textViewLinkAdm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Login.this, Tela_login_adm.class);
                startActivity(intent);
            }
        });

        btn_login.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                String usuarioDigitado = editTextUsuario.getText().toString();
                String senhaDigitada = editTextSenha.getText().toString();

                Eleitor usuario = new Eleitor();

                Boolean resultado = usuario.verificarLogin(usuarioDigitado, senhaDigitada);

                if(resultado){
                    Intent intent = new Intent(Login.this, pesquisa_espontanea.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(Login.this, "Usuario ou a senha Inválido", Toast.LENGTH_SHORT).show();
                }


            }
        });


    }
}