package com.example.pesquisa.user_classes;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.pesquisa.R;
import com.example.pesquisa.classes.BancoDeDados;
import com.example.pesquisa.classes.Eleitor;

import java.time.LocalDate;
import java.time.LocalTime;

public class TelaCadastro extends AppCompatActivity {


    TextView txtCandidato;
    TextView txtProblemas;

    TextView txtData;
    TextView txtHorario;
    EditText edtNome;
    EditText edtCidade;
    EditText edtCelular;

    Button btnFinalizar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela_cadastro);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txtCandidato = findViewById(R.id.txtCandidato);
        txtProblemas = findViewById(R.id.txtProblemas);
        edtCidade = findViewById(R.id.edtCidade);
        txtData = findViewById(R.id.txtData);
        txtHorario = findViewById(R.id.txtHora);
        edtNome = findViewById(R.id.edtNome);
        edtCelular = findViewById(R.id.edtCelular);
        btnFinalizar = findViewById(R.id.btnFinalizar);




        Intent intent = getIntent();
        String candidatoPref = intent.getStringExtra("candidatoPref");
        String candidato = intent.getStringExtra("candidato");
        String problemas = intent.getStringExtra("problemas");

        /*String candidato = intent.getStringExtra("candidato");
        String problemas = intent.getStringExtra("problemas");*/

        txtCandidato.setText("Candidato: " + candidato);
        txtProblemas.setText("Problemas: " + problemas);
        LocalDate dataAtual = LocalDate.now();
        LocalTime horaAtual = LocalTime.now();
        txtData.setText("Data: " + dataAtual.toString());
        txtHorario.setText("Horario: " + horaAtual.toString());


        btnFinalizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = edtNome.getText().toString();
                String cidade = edtCidade.getText().toString();
                String celular = edtCelular.getText().toString();

               Eleitor eleitor = new Eleitor(nome, celular, candidato,candidatoPref, problemas, cidade);

                BancoDeDados.adicionarParticipante(eleitor);
                BancoDeDados.listarParticipantes();

                Toast.makeText(TelaCadastro.this, "Cadastro concluído!", Toast.LENGTH_SHORT).show();

                new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(TelaCadastro.this, pesquisa_espontanea.class);
                        startActivity(intent);
                        finish();
                    }
                }, 1800);

            }
        });



    }



}