    package com.example.pesquisa.user_classes;

    import android.content.Intent;
    import android.os.Bundle;
    import android.view.View;
    import android.view.ViewGroup;
    import android.widget.Button;
    import android.widget.RadioButton;
    import android.widget.RadioGroup;
    import android.widget.Toast;

    import androidx.activity.EdgeToEdge;
    import androidx.appcompat.app.AppCompatActivity;
    import androidx.core.graphics.Insets;
    import androidx.core.view.ViewCompat;
    import androidx.core.view.WindowInsetsCompat;

    import com.example.pesquisa.R;

    import java.util.ArrayList;
    import java.util.List;

    public class TelaCandidatos extends AppCompatActivity {
        Button btnConfirmar;
        RadioGroup grupoCandidatos;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            EdgeToEdge.enable(this);
            setContentView(R.layout.activity_tela_candidatos);
            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });

            String nomeCandidatoPref = getIntent().getStringExtra("candidatoPref");
            String problemas = getIntent().getStringExtra("problemas");

            btnConfirmar = findViewById(R.id.btnConfirmar);
            grupoCandidatos = findViewById(R.id.grupoCandidatos);
            //setupRadioButtons(grupoCandidatos);

            btnConfirmar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                   int idSelecionado = grupoCandidatos.getCheckedRadioButtonId();

                    if (idSelecionado != -1) {
                        RadioButton radioSelecionado = findViewById(idSelecionado);
                        String candSelecionado = radioSelecionado.getText().toString();

                        enviarDados(candSelecionado, nomeCandidatoPref, problemas);


                    }else{
                        Toast.makeText(getApplicationContext(), "Selecione uma opção", Toast.LENGTH_SHORT).show();
                    }


                }
            });




        }

        public void enviarDados(String voto_esti, String nomeCandidato, String problemas){
            Intent enviarDados = new Intent(TelaCandidatos.this, TelaCadastro.class);
            enviarDados.putExtra("candidato", voto_esti);
            enviarDados.putExtra("candidatoPref", nomeCandidato);
            enviarDados.putExtra("problemas", problemas);
            startActivity(enviarDados);
        }


        private void setupRadioButtons(ViewGroup parent) {
            List<RadioButton> radioButtons = getAllRadioButtons(parent);

            for (RadioButton rb : radioButtons) {
                rb.setOnClickListener(v -> {
                    for (RadioButton otherRb : radioButtons) {
                        otherRb.setChecked(false); // desmarca todos
                    }
                    ((RadioButton) v).setChecked(true); // marca só o clicado
                });
            }
        }

        private List<RadioButton> getAllRadioButtons(ViewGroup parent) {
            List<RadioButton> radioButtons = new ArrayList<>();
            findRadioButtonsRecursively(parent, radioButtons);
            return radioButtons;
        }

        private void findRadioButtonsRecursively(ViewGroup parent, List<RadioButton> radioButtons) {
            for (int i = 0; i < parent.getChildCount(); i++) {
                View child = parent.getChildAt(i);
                if (child instanceof RadioButton) {
                    radioButtons.add((RadioButton) child);
                } else if (child instanceof ViewGroup) {
                    findRadioButtonsRecursively((ViewGroup) child, radioButtons);
                }
            }
        }

    }