package com.example.pesquisa.user_classes;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.pesquisa.R;
import com.example.pesquisa.adm_classes.Tela_login_adm;

public class pesquisa_espontanea extends AppCompatActivity {

    Button btnProximo;
    EditText edCandidatoPref;
    TextView TV_link_adm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pesquisa_espontanea);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnProximo = findViewById(R.id.btn_proximo);
        edCandidatoPref = findViewById(R.id.ed_candidato_pref);
        TV_link_adm = findViewById(R.id.TV_link_adm);

        btnProximo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String candidato = edCandidatoPref.getText().toString();
                enviarDados(candidato);

            }
        });

        TV_link_adm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(pesquisa_espontanea.this, Tela_login_adm.class);
                startActivity(intent);
            }
        });








    }

    public void enviarDados(String dados){
        Intent enviarDados = new Intent(pesquisa_espontanea.this, telaProblemas.class);
        enviarDados.putExtra("candidatoPref", dados);
        startActivity(enviarDados);
    }
}