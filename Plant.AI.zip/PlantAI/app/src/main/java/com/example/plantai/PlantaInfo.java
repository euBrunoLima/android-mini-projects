package com.example.plantai;

public class PlantaInfo {
    private String nomeCientifico;
    private String nomePopular;
    private String familia;
    private String origem;
    private String descricaoCompleta;

    // Características físicas e biológicas
    private String cicloVida;       // "anual", "perene", "bianual"
    private String porte;           // "pequeno", "médio", "grande"
    private String alturaMedia;     // ex: "0,5 a 1 metro"
    private String tipoFolhagem;    // "persistente", "caduca"
    private String floração;        //"primavera", "anotodo", etc
    private String corDasFlores;    // ex: "amarela", "azul", etc

    // Requisitos de cuidado
    private int regaMinima;         // em dias
    private int regaMaxima;         // em dias
    private String exigenciaAgua;   // "baixa", "média", "alta"
    private String luminosidade;    // "sol pleno", "meia-sombra", "sombra"
    private String temperaturaIdeal;
    private String substratoIdeal;  // "bem drenado", "rico em matéria orgânica"
    private String adubacao;        // "mensal com NPK", etc

    // Segurança e uso
    private String toxicidade;           // "não tóxica", "tóxica para pets"
    private String usoRecomendado;       // "interior", "jardim", etc

    // Informações complementares
    private String cuidadosEspeciais;    // texto médio
    private String curiosidades;         // texto médio
}
