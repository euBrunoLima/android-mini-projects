package com.example.plantai;

public class Plantas{
    private String nomeEspecie;
    private int frequenciaRega;
    private String dataUltimaRega;

    private int frequenciaPoda;
    private String dataUltimaPoda;

    private int frequenciaTrocaSolo;
    private String dataUltimaTrocaSolo;

    private String observacoes;



    public Plantas(String nomeEspecie, int frequenciaRega, String dataUltimaRega, int frequenciaPoda, String dataUltimaPoda, int frequenciaTrocaSolo, String dataUltimaTrocaSolo, String observacoes) {
        this.nomeEspecie = nomeEspecie;
        this.frequenciaRega = frequenciaRega;
        this.dataUltimaRega = dataUltimaRega;
        this.frequenciaPoda = frequenciaPoda;
        this.dataUltimaPoda = dataUltimaPoda;
        this.frequenciaTrocaSolo = frequenciaTrocaSolo;
        this.dataUltimaTrocaSolo = dataUltimaTrocaSolo;
        this.observacoes = observacoes;
    }



    @Override
    public String toString() {
        return "Plantas{" +
                "nomeEspecie='" + nomeEspecie + '\'' +
                ", frequenciaRega=" + frequenciaRega +
                ", dataUltimaRega='" + dataUltimaRega + '\'' +
                ", frequenciaPoda=" + frequenciaPoda +
                ", dataUltimaPoda='" + dataUltimaPoda + '\'' +
                ", frequenciaTrocaSolo=" + frequenciaTrocaSolo +
                ", dataUltimaTrocaSolo='" + dataUltimaTrocaSolo + '\'' +
                ", observacoes='" + observacoes + '\'' +
                '}';
    }








    public String getNomeEspecie() {
        return nomeEspecie;
    }

    public void setNomeEspecie(String nomeEspecie) {
        this.nomeEspecie = nomeEspecie;
    }

    public String getDataUltimaRega() {
        return dataUltimaRega;
    }

    public void setDataUltimaRega(String dataUltimaRega) {
        this.dataUltimaRega = dataUltimaRega;
    }

    public int getFrequenciaRega() {
        return frequenciaRega;
    }

    public void setFrequenciaRega(int frequenciaRega) {
        this.frequenciaRega = frequenciaRega;
    }

    public int getFrequenciaPoda() {
        return frequenciaPoda;
    }

    public void setFrequenciaPoda(int frequenciaPoda) {
        this.frequenciaPoda = frequenciaPoda;
    }

    public String getDataUltimaPoda() {
        return dataUltimaPoda;
    }

    public void setDataUltimaPoda(String dataUltimaPoda) {
        this.dataUltimaPoda = dataUltimaPoda;
    }

    public int getFrequenciaTrocaSolo() {
        return frequenciaTrocaSolo;
    }

    public void setFrequenciaTrocaSolo(int frequenciaTrocaSolo) {
        this.frequenciaTrocaSolo = frequenciaTrocaSolo;
    }

    public String getDataUltimaTrocaSolo() {
        return dataUltimaTrocaSolo;
    }

    public void setDataUltimaTrocaSolo(String dataUltimaTrocaSolo) {
        this.dataUltimaTrocaSolo = dataUltimaTrocaSolo;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

}
