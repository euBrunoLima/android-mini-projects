    package com.example.plantai;

    import android.view.LayoutInflater;
    import android.view.View;
    import android.view.ViewGroup;
    import android.widget.TextView;
    import android.widget.Toast;

    import androidx.recyclerview.widget.RecyclerView;
    import java.util.List;

    public class PlantasAdapter extends RecyclerView.Adapter<PlantasAdapter.PlantaViewHolder> {

        private List<Plantas> listaPlantas;

        public PlantasAdapter(List<Plantas> listaPlantas) {
            this.listaPlantas = listaPlantas;
        }

        @Override
        public PlantaViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_planta, parent, false);
            return new PlantaViewHolder(view);
        }

        @Override
        public void onBindViewHolder(PlantaViewHolder holder, int position) {
            Plantas planta = listaPlantas.get(position);
            holder.tvNomeEspecie.setText(planta.getNomeEspecie());
            holder.tvFrequenciaRega.setText("Frequência de rega: " + planta.getFrequenciaRega() + " dias");
            holder.tvDataUltimaRega.setText("Última rega: " + planta.getDataUltimaRega());
            holder.tvDataUltimaPoda.setText("Última poda: " + planta.getDataUltimaPoda());
            holder.tvDataUltimaTroca.setText("Última troca: " + planta.getDataUltimaTrocaSolo());

            holder.btnDeletar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    PlantasDBHelper dbHelper = new PlantasDBHelper(v.getContext());
                    boolean sucesso = dbHelper.deletarPlanta(planta.getNomeEspecie());

                    if (sucesso) {
                        listaPlantas.remove(position);
                        notifyItemRemoved(position);
                        notifyItemRangeChanged(position, listaPlantas.size());
                        Toast.makeText(v.getContext(), "Planta apagada!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(v.getContext(), "Erro ao apagar planta.", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @Override
        public int getItemCount() {
            return listaPlantas.size();
        }

        public static class PlantaViewHolder extends RecyclerView.ViewHolder {

            TextView tvNomeEspecie, tvFrequenciaRega, tvDataUltimaRega, btnDeletar, tvDataUltimaPoda, tvDataUltimaTroca;

            public PlantaViewHolder(View itemView) {
                super(itemView);
                tvNomeEspecie = itemView.findViewById(R.id.tvNomeEspecie);
                tvFrequenciaRega = itemView.findViewById(R.id.tvFrequenciaRega);
                tvDataUltimaRega = itemView.findViewById(R.id.tvDataUltimaRega);
                tvDataUltimaPoda = itemView.findViewById(R.id.tvDataUltimaPoda);
                tvDataUltimaTroca = itemView.findViewById(R.id.tvDataUltimaTroca);
                btnDeletar = itemView.findViewById(R.id.btn_deletar);
            }
        }



    }
