package com.example.plantai;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class PlantasDBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "plantas.db";
    private static final int DB_VERSION = 2;

    public static final String TABLE_NAME = "planta";
    public static final String COL_ID = "id";
    public static final String COL_NOME = "nome";
    public static final String COL_REGA = "frequenciaRega";
    public static final String COL_DATA_REGA = "dataUltimaRega";
    public static final String COL_PODA = "frequenciaPoda";
    public static final String COL_DATA_PODA = "dataUltimaPoda";
    public static final String COL_SOLO = "frequenciaTrocaSolo";
    public static final String COL_DATA_SOLO = "dataUltimaTrocaSolo";
    public static final String COL_OBS = "observacoes";

    public PlantasDBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_NOME + " TEXT, " +
                COL_REGA + " INTEGER, " +
                COL_DATA_REGA + " TEXT, " +
                COL_PODA + " INTEGER, " +
                COL_DATA_PODA + " TEXT, " +
                COL_SOLO + " INTEGER, " +
                COL_DATA_SOLO + " TEXT, " +
                COL_OBS + " TEXT)";
        db.execSQL(sql);

        String sqlUser = "CREATE TABLE usuarios (" +
                "email TEXT PRIMARY KEY, " +
                "senha TEXT)";
        db.execSQL(sqlUser);

        ContentValues admin = new ContentValues();
        admin.put("email", "admin123@gmail.com");
        admin.put("senha", "admin123");
        db.insert("usuarios", null, admin);


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS usuarios");
        db.execSQL("DROP TABLE IF EXISTS planta");
        onCreate(db);
    }

    // Inserir planta
    public void inserirPlanta(Plantas planta) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put(COL_NOME, planta.getNomeEspecie());
        valores.put(COL_REGA, planta.getFrequenciaRega());
        valores.put(COL_DATA_REGA, planta.getDataUltimaRega());
        valores.put(COL_PODA, planta.getFrequenciaPoda());
        valores.put(COL_DATA_PODA, planta.getDataUltimaPoda());
        valores.put(COL_SOLO, planta.getFrequenciaTrocaSolo());
        valores.put(COL_DATA_SOLO, planta.getDataUltimaTrocaSolo());
        valores.put(COL_OBS, planta.getObservacoes());

        db.insert(TABLE_NAME, null, valores);
        db.close();
    }

    // Buscar todas as plantas (opcional depois)
    public Cursor getTodasPlantas() {
        SQLiteDatabase db = getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }


    public List<Plantas> listarPlantas() {
        List<Plantas> lista = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        if (cursor.moveToFirst()) {
            do {
                String nome = cursor.getString(cursor.getColumnIndexOrThrow(COL_NOME));
                int rega = cursor.getInt(cursor.getColumnIndexOrThrow(COL_REGA));
                String dataRega = cursor.getString(cursor.getColumnIndexOrThrow(COL_DATA_REGA));
                int poda = cursor.getInt(cursor.getColumnIndexOrThrow(COL_PODA));
                String dataPoda = cursor.getString(cursor.getColumnIndexOrThrow(COL_DATA_PODA));
                int solo = cursor.getInt(cursor.getColumnIndexOrThrow(COL_SOLO));
                String dataSolo = cursor.getString(cursor.getColumnIndexOrThrow(COL_DATA_SOLO));
                String obs = cursor.getString(cursor.getColumnIndexOrThrow(COL_OBS));

                lista.add(new Plantas(nome, rega, dataRega, poda, dataPoda, solo, dataSolo, obs));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return lista;
    }

    public boolean deletarPlanta(String nomeEspecie) {
        SQLiteDatabase db = this.getWritableDatabase();
        int resultado = db.delete("planta", "nome = ?", new String[]{nomeEspecie});
        return resultado > 0;
    }

    public boolean validarLogin(String email, String senha) {
        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "SELECT * FROM usuarios WHERE email = ? AND senha = ?";
        Cursor cursor = db.rawQuery(sql, new String[]{email, senha});

        boolean loginValido = cursor.moveToFirst();

        cursor.close();
        db.close();
        return loginValido;
    }

    public boolean atualizarUsuario(String emailAtual, String novoEmail, String novaSenha) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues valores = new ContentValues();

        if (novoEmail != null && !novoEmail.isEmpty()) {
            valores.put("email", novoEmail);
        }

        // Se quiser atualizar a senha
        if (novaSenha != null && !novaSenha.isEmpty()) {
            valores.put("senha", novaSenha);
        }

        int resultado = db.update(
                "usuarios",
                valores,
                "email = ?",
                new String[]{emailAtual}
        );

        db.close();

        return resultado > 0;
    }

    public Cursor getUnicoUsuario() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM usuarios LIMIT 1", null);
    }


}
