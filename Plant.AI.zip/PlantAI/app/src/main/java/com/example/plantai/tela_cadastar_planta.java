package com.example.plantai;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


public class tela_cadastar_planta extends AppCompatActivity {

    private ImageView ic_home2;
    private ImageView ic_perfil2;
    private ImageView ic_agenda2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela_cadastar_planta);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;

        });

        Button cadastrarPlanta = findViewById(R.id.buttonSalvarPlanta);


        cadastrarPlanta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    String nome = ((EditText) findViewById(R.id.editTextNomeEspecie)).getText().toString();
                    int rega = Integer.parseInt(((EditText) findViewById(R.id.editTextTempoRega)).getText().toString());
                    int poda = Integer.parseInt(((EditText) findViewById(R.id.editTextTempoPoda)).getText().toString());
                    int solo = Integer.parseInt(((EditText) findViewById(R.id.editTextTempoSolo)).getText().toString());
                    String dataRega = ((EditText) findViewById(R.id.editTextDataUltimaRega)).getText().toString();
                    String dataPoda = ((EditText) findViewById(R.id.editTextDataUltimaPoda)).getText().toString();
                    String dataSolo = ((EditText) findViewById(R.id.editTextDataUltimaTrocaSolo)).getText().toString();
                    String observacoes = ((EditText) findViewById(R.id.editTextObservacoes)).getText().toString();
                    Plantas planta = new Plantas(nome, rega, dataRega, poda, dataPoda, solo, dataSolo, observacoes);

                    Toast.makeText(tela_cadastar_planta.this, "Planta salva com sucesso!", Toast.LENGTH_SHORT).show();
                    PlantasDBHelper dbHelper = new PlantasDBHelper(tela_cadastar_planta.this);
                    dbHelper.inserirPlanta(planta);
                    limparCampos();

                }catch (NumberFormatException e){
                    Toast.makeText(tela_cadastar_planta.this, "Por favor, preencha todos os campos numéricos corretamente!", Toast.LENGTH_SHORT).show();
                }

            }
        });

        ic_home2 = findViewById(R.id.ic_home);
        ic_perfil2 = findViewById(R.id.ic_perfil2);
        ic_agenda2 = findViewById(R.id.ic_agenda2);


        ic_home2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent home_pah = new Intent(tela_cadastar_planta.this, tela_home.class);
                startActivity(home_pah);
                finish();
            }
        });



        ic_perfil2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ic_perfil = new Intent(tela_cadastar_planta.this, tela_perfil.class);
                startActivity(ic_perfil);
                finish();
            }
        });


    }


    private void limparCampos() {
        ((EditText) findViewById(R.id.editTextNomeEspecie)).setText("");
        ((EditText) findViewById(R.id.editTextTempoRega)).setText("");
        ((EditText) findViewById(R.id.editTextTempoPoda)).setText("");
        ((EditText) findViewById(R.id.editTextTempoSolo)).setText("");
        ((EditText) findViewById(R.id.editTextDataUltimaRega)).setText("");
        ((EditText) findViewById(R.id.editTextDataUltimaPoda)).setText("");
        ((EditText) findViewById(R.id.editTextDataUltimaTrocaSolo)).setText("");
        ((EditText) findViewById(R.id.editTextObservacoes)).setText("");
    }


}