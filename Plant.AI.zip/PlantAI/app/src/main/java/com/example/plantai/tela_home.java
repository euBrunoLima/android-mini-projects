package com.example.plantai;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class tela_home extends AppCompatActivity {

    private ImageView ic_home;
    private ImageView ic_perfil;
    private ImageView add_planta;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela_home);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        RecyclerView rvPlantas = findViewById(R.id.rvPlantas);
        TextView tvEmpty = findViewById(R.id.tvEmpty);

// Obter dados do banco
        PlantasDBHelper dbHelper = new PlantasDBHelper(this);
        List<Plantas> plantas = dbHelper.listarPlantas();

        if (plantas.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            rvPlantas.setVisibility(View.GONE);
        } else {
            tvEmpty.setVisibility(View.GONE);
            rvPlantas.setVisibility(View.VISIBLE);
        }

// Configurar RecyclerView
        PlantasAdapter adapter = new PlantasAdapter(plantas);
        rvPlantas.setLayoutManager(new LinearLayoutManager(this));
        rvPlantas.setAdapter(adapter);


        System.out.println(Plantas.class.toString());


        add_planta = findViewById(R.id.add_planta);
        ic_home = findViewById(R.id.ic_home);
        ic_perfil = findViewById(R.id.ic_perfil);


        add_planta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent path_add = new Intent(tela_home.this, tela_cadastar_planta.class);
                startActivity(path_add);

            }
        });
        ic_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ic_home = new Intent(tela_home.this, tela_home.class);
                startActivity(ic_home);
                finish();
            }
        });

        ic_perfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ic_perfil = new Intent(tela_home.this, tela_perfil.class);
                startActivity(ic_perfil);
                finish();
            }
        });








    }
}