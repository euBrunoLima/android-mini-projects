package com.example.plantai;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class tela_login extends AppCompatActivity {

    private EditText emailInput, passwordInput;
    private TextView testCredentials;
    private Button login_button, btn_up;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        emailInput = findViewById(R.id.emailInput);
        passwordInput = findViewById(R.id.passwordInput);
        btn_up = findViewById(R.id.btn_up);
        login_button = findViewById(R.id.loginButton);
        testCredentials = findViewById(R.id.testCredentials);


        PlantasDBHelper db2 = new PlantasDBHelper(this);

        SQLiteDatabase banco = db2.getReadableDatabase();

        Cursor cursor = banco.rawQuery("SELECT email, senha FROM usuarios LIMIT 1", null);

        if (cursor.moveToFirst()) {
            String emailDB = cursor.getString(0);
            String senhaDB = cursor.getString(1);

            testCredentials.setText(
                    "Email para teste: " + emailDB + "\nSenha: " + senhaDB
            );
        } else {
            testCredentials.setText("Nenhum usuário encontrado.");
        }

        cursor.close();



        btn_up.setOnClickListener(v ->{
            Intent path_up = new Intent(tela_login.this, tela_up_dados.class);
            startActivity(path_up);
            finish();
        });


        login_button.setOnClickListener( v ->{
            Toast.makeText(tela_login.this, "Clique detectado!", Toast.LENGTH_SHORT).show();

            String email = emailInput.getText().toString().trim();
            String senha = passwordInput.getText().toString().trim();

            PlantasDBHelper db = new PlantasDBHelper(tela_login.this);

            if (db.validarLogin(email, senha)) {

                Intent intent = new Intent(tela_login.this, tela_home.class);
                startActivity(intent);
            } else {

                Toast.makeText(tela_login.this, "Email ou senha incorretos!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}