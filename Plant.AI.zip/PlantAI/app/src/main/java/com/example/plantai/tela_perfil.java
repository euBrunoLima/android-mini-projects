package com.example.plantai;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class tela_perfil extends AppCompatActivity {

    private ImageView ic_home;
    private ImageView ic_perfil;
    private ImageView add_planta;
    private Button buttonsair, btn_up_date;
    private TextView textEmailUsuario, textSenhaUsuario;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela_perfil);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        ic_home = findViewById(R.id.ic_home);
        ic_perfil = findViewById(R.id.ic_perfil);
        add_planta = findViewById(R.id.add_planta);
        buttonsair = findViewById(R.id.buttonSair);
        btn_up_date = findViewById(R.id.btn_up_date);

        textEmailUsuario = findViewById(R.id.textEmailUsuario);
        textSenhaUsuario = findViewById(R.id.senhaUsuario);

        // 🔥 instancia o banco
        PlantasDBHelper db = new PlantasDBHelper(this);

        // 🔥 busca o unico usuario
        Cursor cursor = db.getUnicoUsuario();

        if (cursor.moveToFirst()) {
            String email = cursor.getString(cursor.getColumnIndexOrThrow("email"));
            String senha = cursor.getString(cursor.getColumnIndexOrThrow("senha"));

            textEmailUsuario.setText(email);
            textSenhaUsuario.setText("senha: " + senha);
        }

        cursor.close();




        ic_home.setOnClickListener(v ->{
            Intent ic_home = new Intent(tela_perfil.this, tela_home.class);
            startActivity(ic_home);
            finish();
        });

        ic_perfil.setOnClickListener(v ->{
            Intent ic_perfil = new Intent(tela_perfil.this, tela_perfil.class);
            startActivity(ic_perfil);
            finish();
        });

        add_planta.setOnClickListener(v ->{
            Intent path_add = new Intent(tela_perfil.this, tela_cadastar_planta.class);
            startActivity(path_add);
            finish();
        });
        buttonsair.setOnClickListener(v -> sairDoApp());

        btn_up_date.setOnClickListener(v -> {
            Intent path_up = new Intent(tela_perfil.this, tela_up_dados.class);
            startActivity(path_up);
            finish();
        });



    }

    private void sairDoApp() {
        finishAffinity();   // Encerra todas as Activities
        System.exit(0);     // Finaliza o processo
    }





}