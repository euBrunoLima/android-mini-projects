package com.example.plantai;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class tela_up_dados extends AppCompatActivity {

    private ImageView ic_home;
    private ImageView ic_perfil;
    private ImageView add_planta;

    private EditText editTextNovoEmail, editTextNovaSenha;
    private Button buttonAtualizarConta;

    private String emailAtual = "admin123@gmail.com";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela_up_dados);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editTextNovoEmail = findViewById(R.id.editTextNovoEmail);
        editTextNovaSenha = findViewById(R.id.editTextNovaSenha);
        buttonAtualizarConta = findViewById(R.id.buttonAtualizarConta);

        buttonAtualizarConta.setOnClickListener(v ->{
            atualizarDadosUsuario();
        });


        ic_home = findViewById(R.id.ic_home);
        ic_perfil = findViewById(R.id.ic_perfil);
        add_planta = findViewById(R.id.add_planta);


        ic_home.setOnClickListener(v ->{
            Intent ic_home = new Intent(tela_up_dados.this, tela_home.class);
            startActivity(ic_home);
            finish();
        });

        ic_perfil.setOnClickListener(v ->{
            Intent ic_perfil = new Intent(tela_up_dados.this, tela_perfil.class);
            startActivity(ic_perfil);
            finish();
        });

        add_planta.setOnClickListener(v ->{
            Intent path_add = new Intent(tela_up_dados.this, tela_cadastar_planta.class);
            startActivity(path_add);
            finish();
        });
    }


    private void atualizarDadosUsuario() {
        Toast.makeText(this, "Clique detectado!", Toast.LENGTH_SHORT).show();

        String novoEmail = editTextNovoEmail.getText().toString().trim();
        String novaSenha = editTextNovaSenha.getText().toString().trim();

        if (novoEmail.isEmpty() || novaSenha.isEmpty()) {
            Toast.makeText(this, "Digite algo para atualizar!", Toast.LENGTH_SHORT).show();
            return;
        }
        try{
            PlantasDBHelper db = new PlantasDBHelper(this);

            boolean sucesso = db.atualizarUsuario(emailAtual, novoEmail, novaSenha);

            if (sucesso) {
                Toast.makeText(this, "Dados atualizados com sucesso!", Toast.LENGTH_LONG).show();
                finish();
            }else {
                Toast.makeText(this, "Erro ao atualizar. Verifique as informações!", Toast.LENGTH_LONG).show();
            }
        }catch (Exception e){
            Toast.makeText(this, "Erro ao atualizar. Verifique as informações!", Toast.LENGTH_LONG).show();
            e.printStackTrace();

        }


    }
}