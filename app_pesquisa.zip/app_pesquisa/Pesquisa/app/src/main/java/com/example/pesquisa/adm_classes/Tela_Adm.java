package com.example.pesquisa.adm_classes;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.pesquisa.classes.BancoDeDados;

import com.example.pesquisa.R;
import com.example.pesquisa.classes.Eleitor;

import java.util.ArrayList;

public class Tela_Adm extends AppCompatActivity {

    EditText inputNome, inputCidade, inputCandidato;
    Button btnBuscarNome, btnBuscarCidade, btnExibirTodos, btnBuscarCandidato, btnLimpar;
    TextView textResultado, textTotal;
    Spinner spinner_candidatos;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela_adm);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        inputNome = findViewById(R.id.inputNome);
        inputCidade = findViewById(R.id.inputCidade);
       //inputCandidato = findViewById(R.id.inputCandidato);
        btnBuscarNome = findViewById(R.id.btnBuscarNome);
        btnBuscarCidade = findViewById(R.id.btnBuscarCidade);
        btnLimpar = findViewById(R.id.btnLimpar);
        btnBuscarCandidato = findViewById(R.id.btnBuscarCandidato);
        btnExibirTodos = findViewById(R.id.btnExibirTodos);
        textResultado = findViewById(R.id.textResultado);
        textTotal = findViewById(R.id.textTotal);
        spinner_candidatos = findViewById(R.id.spinner_candidatos);

        String candidatos[] = {"Alegria", "Tristeza", "Ansiedade", "Raiva", "Inveja", "Branco", "Nulo", "Não Sabe"};

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, candidatos);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_candidatos.setAdapter(adapter);




    
        btnLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inputNome.setText("");
                inputCidade.setText("");
                inputCandidato.setText("");
                textResultado.setText("");
            }
        });


        atualizarTotal();

        btnBuscarNome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buscarPorNome();
            }
        });

        btnBuscarCidade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buscarPorCidade();
            }
        });

        btnBuscarCandidato.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v){
                  buscarPorCandidato();
              }
          });


        btnExibirTodos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exibirTodos();
            }
        });
    }






    private void atualizarTotal() {
        int total = BancoDeDados.contarVotos();
        textTotal.setText("Total de Participantes: " + total);
    }

    private void buscarPorNome() {
        String nome = inputNome.getText().toString().trim();
        ArrayList<Eleitor> encontrados = BancoDeDados.buscarPorNome(nome);

        if (encontrados.isEmpty()) {
            textResultado.setText("Nenhum participante com esse nome.");
        } else {
            Eleitor e = encontrados.get(0);
            textResultado.setText(formatarSaida(e));
        }
    }

    private void buscarPorCidade() {
        String cidade = inputCidade.getText().toString().trim();
        ArrayList<Eleitor> encontrados = BancoDeDados.buscarPorCidade(cidade);

        if (encontrados.isEmpty()) {
            textResultado.setText("Nenhum participante encontrado na cidade \"" + cidade + "\".");
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append(encontrados.size()).append(" participantes encontrados em \"").append(cidade).append("\"\n\n");
            for (int i = 0; i < encontrados.size(); i++) {
                sb.append(formatarSaida(encontrados.get(i))).append("\n");
            }
            textResultado.setText(sb.toString());
        }
    }

    private void buscarPorCandidato() {

        String candidatoSelecionado = spinner_candidatos.getSelectedItem().toString().trim();

       // String candidato = inputCandidato.getText().toString().trim();
        int total = BancoDeDados.contarVotosPorCandidato(candidatoSelecionado);

        textResultado.setText("Total de votos para " + candidatoSelecionado + ": " + total);

    }


    private void exibirTodos() {
        ArrayList<Eleitor> todos = BancoDeDados.listaParticipantes;
        if (todos.isEmpty()) {
            textResultado.setText("Nenhum participante cadastrado.");
        } else {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < todos.size(); i++) {
                sb.append("=== Dados do Participante ").append(i + 1).append(" ===\n");
                sb.append(formatarSaida(todos.get(i))).append("\n\n");
            }
            textResultado.setText(sb.toString());
        }
    }

    private String formatarSaida(Eleitor e) {
        return "\n===== Eleitor =====\n"
                +"Nome: " + e.getNome() + "\n"
                + "Cidade: " + e.getCidade() + "\n"
                + "Celular: " + e.getCelular() + "\n"
                + "Data: " + e.getData() + "\n"
                + "Hora: " + e.getDataHora() + "\n"
                + "\n[Voto: NÃO EXIBIDO]\n";
    }
}