package com.example.pesquisa.classes;

public class Administrador {
    private String usuario = "Administrador";
    private String senha = "adm123";

    public Administrador(){}






    public Boolean verificarLogin(String usuarioDigitado, String senhaDigitada){
        return usuarioDigitado.equals(getUsuario()) && senhaDigitada.equals(getSenha());
    }





















    public String getUsuario(){
        return usuario;
    }
    public String getSenha() {
        return senha;
    }
}
