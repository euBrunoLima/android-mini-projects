package com.example.pesquisa.classes;

import java.util.ArrayList;

public class BancoDeDados {
    public static ArrayList<Eleitor> listaParticipantes = new ArrayList<>();

    public static void adicionarParticipante(Eleitor eleitor) {
        listaParticipantes.add(eleitor);

    }

    public static void listarParticipantes() {
        for (Eleitor eleitor : listaParticipantes) {
            System.out.println(eleitor);
        }
    }

    public static int contarVotos(){
        return listaParticipantes.size();
    }


    public static ArrayList<Eleitor> buscarPorNome(String nome) {
        ArrayList<Eleitor> encontrados = new ArrayList<>();
        for (Eleitor e : listaParticipantes) {
            if (e.getNome().equalsIgnoreCase(nome)) {
                encontrados.add(e);
            }
        }
        return encontrados;
    }

    public static ArrayList<Eleitor> buscarPorCidade(String cidade) {
        ArrayList<Eleitor> encontrados = new ArrayList<>();
        for (Eleitor e : listaParticipantes) {
            if (e.getCidade().equalsIgnoreCase(cidade)) {
                encontrados.add(e);
            }
        }
        return encontrados;
    }

    public static int contarVotosPorCandidato(String nomeCandidato) {
        int contador = 0;
        for (Eleitor eleitor : listaParticipantes) {
            if (eleitor.getVoto().equalsIgnoreCase(nomeCandidato)) {
                contador++;
            }
        }
        return contador;
    }

    public static Eleitor buscarPorID(int id) {
        if (id >= 0 && id < listaParticipantes.size()) {
            return listaParticipantes.get(id);
        }
        return null;
    }

    public static int contarPorCidade(String cidade) {
        int count = 0;
        for (Eleitor e : listaParticipantes) {
            if (e.getCidade().equalsIgnoreCase(cidade)) {
                count++;
            }
        }
        return count;
    }

}
