package com.example.pesquisa.user_classes;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.pesquisa.R;

public class telaProblemas extends AppCompatActivity {

    EditText edtProblema1;
    EditText edtProblema2;
    EditText edtProblema3;
    Button btnContinuar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela_problemas);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        String nomeCandidatoPref = getIntent().getStringExtra("candidatoPref");


        edtProblema1 = findViewById(R.id.edtProblema1);
        edtProblema2 = findViewById(R.id.edtProblema2);
        edtProblema3 = findViewById(R.id.edtProblema3);
        btnContinuar = findViewById(R.id.btnContinuar);


        btnContinuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String problema1 = edtProblema1.getText().toString().trim();
                String problema2 = edtProblema2.getText().toString().trim();
                String problema3 = edtProblema3.getText().toString().trim();

                if (problema1.isEmpty() || problema2.isEmpty() || problema3.isEmpty()) {
                   Toast.makeText(getApplicationContext(), "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                } else{
                    String problemas = problema1 + "," + problema2 + "," + problema3;
                    enviarDados(nomeCandidatoPref, problemas);
                }

            }

        });


    }


  public void enviarDados(String nomeCandidato, String problemas ){
      Intent enviarDados = new Intent(telaProblemas.this, TelaCandidatos.class);
      enviarDados.putExtra("candidatoPref", nomeCandidato);
      enviarDados.putExtra("problemas", problemas);
      startActivity(enviarDados);

  }

}