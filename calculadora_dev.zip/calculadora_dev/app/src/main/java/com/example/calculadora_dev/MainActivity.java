package com.example.calculadora_dev;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private EditText edNumero;
    private Spinner spConversao;
    private TextView txtResultado;
    private Button btnConverter;
    private String escolhaConversao;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edNumero = findViewById(R.id.edNumero);
        spConversao = findViewById(R.id.spConversao);
        txtResultado = findViewById(R.id.txtResultado);
        btnConverter = findViewById(R.id.btnConverter);


        List<String> opcoes = Arrays.asList(
                "Decimal -> Binário",
                "Binário -> Decimal",
                "Decimal -> Octal",
                "Octal -> Decimal",
                "Decimal -> Hexadecimal",
                "Hexadecimal -> Decimal",
                "Binário -> Hexadecimal",
                "Hexadecimal -> Binário"
        );


        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, opcoes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spConversao.setAdapter(adapter);


        spConversao.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                escolhaConversao = opcoes.get(position); // Atualiza a variável com a seleção
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                escolhaConversao = null;
            }
        });


        btnConverter.setOnClickListener(v -> converter());
    }

    private void converter() {
        String numero = edNumero.getText().toString();
        String resultado = "";

        if (numero.isEmpty()) {
            Toast.makeText(this, "Digite um número!", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            switch (escolhaConversao) {
                case "Decimal -> Binário":
                    resultado = Integer.toBinaryString(Integer.parseInt(numero));
                    break;
                case "Binário -> Decimal":
                    resultado = String.valueOf(Integer.parseInt(numero, 2));
                    break;
                case "Decimal -> Octal":
                    resultado = Integer.toOctalString(Integer.parseInt(numero));
                    break;
                case "Octal -> Decimal":
                    resultado = String.valueOf(Integer.parseInt(numero, 8));
                    break;
                case "Decimal -> Hexadecimal":
                    resultado = Integer.toHexString(Integer.parseInt(numero)).toUpperCase();
                    break;
                case "Hexadecimal -> Decimal":
                    resultado = String.valueOf(Integer.parseInt(numero, 16));
                    break;
                case "Binário -> Hexadecimal":
                    resultado = Integer.toHexString(Integer.parseInt(numero, 2)).toUpperCase();
                    break;
                case "Hexadecimal -> Binário":
                    resultado = Integer.toBinaryString(Integer.parseInt(numero, 16));
                    break;
                default:
                    resultado = "Erro na conversão!";
                    break;
            }
        } catch (Exception e) {
            resultado = "Entrada inválida!";
        }

        txtResultado.setText(resultado);
    }
}
