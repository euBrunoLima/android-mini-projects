package com.example.combustivel;

public class Combustivel {

    private double etanol;
    private double gasolina = 5.40;

    public Combustivel(double etanol) {
        this.etanol = etanol;
    }
    public Combustivel(){}



    public String calcularEtanol(){

       double resultado = getEtanol() / getGasolina();
       if(resultado >= 0.7){
           return "Abasteça com gasolina";
       }else{
           return "Abasteça com etanol";
       }
    }

    public String limpar(){
        return "";
    }

   public double getGasolina() {
       return gasolina;
   }

   public double getEtanol(){
        return  etanol;
   }
}
