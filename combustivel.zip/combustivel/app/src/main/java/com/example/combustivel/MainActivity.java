package com.example.combustivel;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText et_vlrEtanol;
    private TextView tv_resultado;
    private Button btn_calcular;
    private Button btn_limpar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        et_vlrEtanol = findViewById(R.id.et_vlrEtanol);
        tv_resultado = findViewById(R.id.tv_resultado);
        btn_calcular = findViewById(R.id.btn_calcular);
        btn_limpar = findViewById(R.id.btn_limpar);




        btn_calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double etanol = Double.parseDouble(et_vlrEtanol.getText().toString());
                Combustivel combustivel = new Combustivel(etanol);

                tv_resultado.setText(combustivel.calcularEtanol());

            }

        });

        btn_limpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Combustivel combustivel = new Combustivel();

                et_vlrEtanol.setText(combustivel.limpar());
                tv_resultado.setText(combustivel.limpar());
            }

        });




    }
}