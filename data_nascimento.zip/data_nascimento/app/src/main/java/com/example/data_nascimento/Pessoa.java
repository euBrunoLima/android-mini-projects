package com.example.data_nascimento;

import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.time.format.DateTimeFormatter;


public class Pessoa {
    public String nome;
    public int idade;

    public Pessoa(String nome, int idade){
        this.nome = nome;
        this.idade = idade;
    }

    public String calcularIdade(){
        LocalDate hoje = LocalDate.now();
        Period periodo = Period.between(dataNascimento, hoje);

        long anos = periodo.getYears();
        long meses = ChronoUnit.MONTHS.betwdeen(dataNascimento, hoje);
        long dias = ChronoUnit.DAYS.between(ataNascimento, hoje);
        long horas = dias * 24;
        long minutos = horas * 60;
        long segundos = minutos * 60;


        return "Nome: " + nome + "\n" +
                "Idade em anos: " + anos + "\n" +
                "Idade em meses: " + meses + "\n" +
                "Idade em dias: " + dias + "\n" +
                "Idade em horas: " + horas + "\n" +
                "Idade em minutos: " + minutos + "\n" +
                "Idade em segundos: " + segundos;



    }
}

