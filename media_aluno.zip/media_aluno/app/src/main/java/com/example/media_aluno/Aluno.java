package com.example.media_aluno;


import java.util.Arrays;

public class Aluno {

    private double nota1;
    private double nota2;
    private double nota3;
    private int faltas;

    public  Aluno(double nota1, double nota2, double nota3, int faltas) {
        this.nota1 = nota1;
        this.nota2 = nota2;
        this.nota3 = nota3;
        this.faltas = faltas;
    }


    public String calcularMedia() {

        double[] vet = {nota1, nota2, nota3};
        Arrays.sort(vet);


        double media = (vet[1] + vet[2]) / 2;


        if(media >= 6 && faltas <= 5){
            return "Aprovado por nota e falta";
        }
        else if(media < 6 && faltas > 5){
            return "Reprovado por nota e falta";
        }
        else if(media >= 6 && faltas > 5){
            return "Reprovado por falta";
        }
        else{
            return "Reprovado por nota";
        }



    }
}


