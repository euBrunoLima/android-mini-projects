package com.example.media_aluno;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText edNota1;
    private EditText edNota2;
    private EditText edNota3;
    private EditText edFaltas;
    private Button btnCalcular;
    private TextView tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        edNota1 = findViewById(R.id.edNota1);
        edNota2 = findViewById(R.id.edNota2);
        edNota3 = findViewById(R.id.edNota3);
        edFaltas = findViewById(R.id.edFaltas);



        btnCalcular = findViewById(R.id.btnCalcular);
        tvResultado = findViewById(R.id.tvResultado);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                double nota1 = Double.parseDouble(edNota1.getText().toString());
                double nota2 = Double.parseDouble(edNota2.getText().toString());
                double nota3 = Double.parseDouble(edNota3.getText().toString());
                int faltas = Integer.parseInt(edFaltas.getText().toString());

                Aluno aluno = new Aluno(nota1, nota2, nota3, faltas);

                tvResultado.setText(aluno.calcularMedia());
            }
        });


    }
}