package com.example.pesquisa_metro;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class tela_pesquisa extends AppCompatActivity {

    Spinner  spinner_origem_amarela;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela_pesquisa);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        spinner_origem_amarela = findViewById(R.id.spinner_origem_amarela);

        String[] estacoesLinhaAmarela = {
                "Luz",
                "República",
                "Higienópolis-Mackenzie",
                "Paulista",
                "Oscar Freire",
                "Fradique Coutinho",
                "Faria Lima",
                "Pinheiros",
                "Butantã",
                "São Paulo-Morumbi",
                "Vila Sônia"
        };


        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, estacoesLinhaAmarela);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_origem_amarela.setAdapter(adapter);


    }
}