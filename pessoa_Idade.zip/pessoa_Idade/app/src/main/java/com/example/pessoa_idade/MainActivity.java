package com.example.pessoa_idade;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class MainActivity extends AppCompatActivity {

    private EditText edNome;
    private EditText edDataNascimento;
    private Button btnCalcular;
    private TextView txtResultado;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        edNome = findViewById(R.id.edNome);
        edDataNascimento = findViewById(R.id.edDataNascimento);
        btnCalcular = findViewById(R.id.btnCalcular);
        txtResultado = findViewById(R.id.tvResultado);


        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String nome = edNome.getText().toString();


                String dataNascimento = edDataNascimento.getText().toString();
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDate Nascimento = LocalDate.parse(dataNascimento, formatter);

                txtResultado.setText(Nascimento.toString());

                if (nome.isEmpty() || dataNascimento.isEmpty()) {
                    txtResultado.setText("Preencha todos os campos!");
                    return;
                }


                Pessoa pessoa = new Pessoa(nome, Nascimento);

                pessoa.calcularIdade();
               txtResultado.setText(pessoa.calcularIdade());
                //txtResultado.setText("test");
            }
        });
    }

}