package com.example.pessoa_idade;

import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;

public class Pessoa {
    public String nome;
    public LocalDate dataNascimento;

    public Pessoa(String nome, LocalDate dataNascimento) {
        this.nome = nome;
        this.dataNascimento = dataNascimento;
    }

    public String calcularIdade(){

        LocalDate hoje = LocalDate.now();
        Period periodo = Period.between(dataNascimento, hoje);

        long anos = periodo.getYears();
        long meses = ChronoUnit.MONTHS.between(dataNascimento, hoje);
        long dias = ChronoUnit.DAYS.between(dataNascimento, hoje);
        long horas = dias * 24;
        long minutos = horas * 60;
        long segundos = minutos * 60;

        return "Nome: " + nome + "\n" +
                "Idade em anos: " + anos + "\n" +
                "Idade em meses: " + meses + "\n" +
                "Idade em dias: " + dias + "\n" +
                "Idade em horas: " + horas + "\n" +
                "Idade em minutos: " + minutos + "\n" +
                "Idade em segundos: " + segundos;
    }


}
