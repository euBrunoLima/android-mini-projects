package com.example.html5_quiz;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class QuizActivity extends AppCompatActivity {

    private TextView questionText;
    private RadioGroup optionsGroup;
    private Button nextButton;

    private List<Question> questionList;
    private int currentQuestionIndex = 0;
    private int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_quiz);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        questionText = findViewById(R.id.questionText);
        optionsGroup = findViewById(R.id.optionsGroup);
        nextButton = findViewById(R.id.nextButton);


        loadQuestions();
        showQuestion();

        nextButton.setOnClickListener(v -> {
            int selectedId = optionsGroup.getCheckedRadioButtonId();
            if (selectedId != -1) {
                RadioButton selectedOption = findViewById(selectedId);
                int answerIndex = optionsGroup.indexOfChild(selectedOption);

                if (answerIndex == questionList.get(currentQuestionIndex).getCorrectAnswerIndex()) {
                    score++;
                }

                currentQuestionIndex++;
                if (currentQuestionIndex < questionList.size()) {
                    showQuestion();
                } else {
                    Intent intent = new Intent(QuizActivity.this, ResultActivity.class);
                    intent.putExtra("score", score);
                    intent.putExtra("total", questionList.size());
                    startActivity(intent);
                    finish();
                }
            }
        });
    }

    private void loadQuestions() {
        questionList = new ArrayList<>();
        questionList.add(new Question("1) Qual tag define o documento como HTML5?",
                Arrays.asList("<!DOCTYPE html>", "<html5>", "<doctype>", "<document>"), 0));
        questionList.add(new Question("2) Qual tag é usada para vídeo em HTML5?",
                Arrays.asList("<media>", "<video>", "<movie>", "<play>"), 1));
        questionList.add(new Question("3) Qual tag substitui o <b> para dar ênfase semântica?",
                Arrays.asList("<strong>", "<em>", "<highlight>", "<i>"), 0));
        questionList.add(new Question("4) Qual atributo do <audio> permite tocar automaticamente?",
                Arrays.asList("autoplay", "play", "start", "auto"), 0));
        questionList.add(new Question("5) Qual tag cria um campo de entrada de e-mail?",
                Arrays.asList("<input type='mail'>", "<input type='text'>", "<input type='email'>", "<input type='user'>"), 2));
        questionList.add(new Question("6) Qual tag representa conteúdo independente?",
                Arrays.asList("<section>", "<article>", "<div>", "<header>"), 1));
        questionList.add(new Question("7) Qual tag representa a navegação?",
                Arrays.asList("<nav>", "<menu>", "<aside>", "<header>"), 0));
        questionList.add(new Question("8) Qual atributo especifica texto alternativo em imagens?",
                Arrays.asList("alt", "title", "description", "src"), 0));
        questionList.add(new Question("9) Qual tag é usada para desenhar gráficos em HTML5?",
                Arrays.asList("<graphic>", "<draw>", "<canvas>", "<paint>"), 2));
        questionList.add(new Question("10) Qual tag é usada para incorporar conteúdo interativo?",
                Arrays.asList("<iframe>", "<embed>", "<object>", "Todas as anteriores"), 3));
    }

    private void showQuestion() {
        Question q = questionList.get(currentQuestionIndex);
        questionText.setText(q.getQuestionText());
        optionsGroup.clearCheck();

        for (int i = 0; i < optionsGroup.getChildCount(); i++) {
            ((RadioButton) optionsGroup.getChildAt(i)).setText(q.getOptions().get(i));
        }
    }
}